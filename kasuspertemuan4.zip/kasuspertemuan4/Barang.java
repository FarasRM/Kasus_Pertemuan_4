/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.kasuspertemuan4;

/**
 *
 * @author acer
 */
public class Barang {
        String kode_barang;
        String nama_barang;
        int stok;
        
        public Barang(String kode, String nama, int stk) 
        {
                kode_barang = kode;
                nama_barang = nama;
                stok = stk;
        }
            public int getstock() {
            return stok;
        }
        
        public void setstok(int stok){
            this.stok += stok;
        }

}
