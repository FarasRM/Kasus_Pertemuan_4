/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.kasuspertemuan4;

/**
 *
 * @author acer
 */
public class KelasSatu 
{
        {   
            System.out.println(11);
        }
        
            static

        {
            System.out.println(2);
        }

            public KelasSatu(int i)
        {
            
            System.out.println(3);

        }
            
            public KelasSatu()
        
        {
    
            System.out.println(4);

        }
            
}
